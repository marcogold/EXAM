﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinsaWeb.Views.Shared
{
    public class ViewBag
    {
        public string TestoTitolo { get; set; }
    }
}
