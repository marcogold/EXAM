﻿using System;

public class CorsiAllievi
{
    public int IDAllievo { get; set; }
    public string IDEdizioneCorso { get; set; }
    public int Voto { get; set; }
}