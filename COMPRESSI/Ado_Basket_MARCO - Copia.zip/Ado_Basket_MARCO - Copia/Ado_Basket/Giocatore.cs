﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado_Basket
{
    class Giocatore
    {
        public int idGiocatore { get; }
        public string nome { get; set; }
        public string cognome { get; set; }
        public DateTime dataNascita { get; set; }
        public string nickname { get; set; }
        public int livello { get; set; }
        
        public Giocatore(string nome, string cognome, DateTime dataNascita, string nickname, int livello)
        {
            this.nome = nome;
            this.cognome = cognome;
            this.dataNascita = dataNascita;
            this.nickname = nickname;
            this.livello = livello;
        }
    }
}
