﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Ado_Basket
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("               **************  BUONGIORNO!  ***************");
            Console.WriteLine("       Benvenuto nel nostro gestionale del campo da basket di Pegli 2");
            Console.WriteLine("\n\nPremi invio per iniziare\n");
            Console.ReadLine();
            TorreControllo Controllo = new TorreControllo();
            string digit = null;
            do
            {
                Console.WriteLine("\nChe azione vuoi eseguire?\n" +
                    " p -> Aggiungi nuova Partita\n" +
                    " g -> Aggiungi nuovo Giocatore\n" +
                    " c -> Cerca Partita per data\n" +
                    " m -> Cerca giocatori per età\n" +
                    " lg -> Lista di giocatori nel database\n" +
                    " pp -> Partite in programma\n" +
                    " del -> Cancella un giocatore\n" +
                    " exit -> (TERMINA)\n");
                digit = Console.ReadLine();
                switch (digit)
                {
                    case "p":
                    case "P":
                        {
                            Controllo.IscrizionePartita();
                            break;
                        }
                    case "g":
                    case "G":
                        {
                            Controllo.IscrizioneGiocatore();
                            break;
                        }
                    case "c":
                    case "C":
                        {
                            Controllo.PartiteInData();
                            //Console.WriteLine("Inserisci la data della partita:");
                            //String valore = Console.ReadLine();
                            //DateTime data = DateTime.Parse(valore);
                            //Controllo.PartiteInData(data);
                            break;
                        }
                    case "m":
                    case "M":
                        {
                            Controllo.ValoreMedG();
                            break;
                        }
                    case "LG":
                    case "lg":
                        {
                            Controllo.ListaGiocatori();
                            break;
                        }
                    case "PP":
                    case "pp":
                        {
                            Controllo.PartiteInProgramma();
                            break;
                        }
                    case "DEL":
                    case "del":
                        {
                            Controllo.Elimina();
                            break;
                        }
                }
                //if (digit != "a" && digit != "b" && digit != "c" && digit != "d" && digit != "e" && digit != "f" && digit != "g" && digit != "h" && digit != "i" && digit != "l" && digit != "m" && digit != "n" && digit != "exit")
                //Console.WriteLine("\n*******Cio' che hai inserito non esiste nell'elenco********");
            }
            while (digit != "exit");
        }
    }
}

