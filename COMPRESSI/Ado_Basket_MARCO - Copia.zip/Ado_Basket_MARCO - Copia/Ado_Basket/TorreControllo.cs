﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado_Basket
{
   
    static class Stringa // in una classe statica avulsa dal resto, così la puoi richiamare quando e dove vuoi
    {
        public static string CONN_STRING = @"Data Source=(localdb)\MSSQLLocalDB;
                                        Initial Catalog=BasketStation;Integrated Security=True;
                                        Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;
                                        ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    }

    class TorreControllo
    {
        //  Q U E R Y  //
        //Stampami le partite di quel giorno
        private static string STAMPA_PARTITE_IN_DATA = @"
            SELECT *
            FROM dbo.Partite as P
            WHERE  P.OraInizio BETWEEN @Data AND DATEADD(day,1,@Data)
         ";
            //WHERE  P.OraInizio>=@Data AND p.OraInizio<=DATEADD(day,1,CAST(@Data as datetime)) UGUALE A BETWEEN

        //Aggiungi una partita nel database
        //PER INSERIRE I VALORI ANCHE NELLA TABELLA DI CONGIUNZIONE PROBAB SERVE UN'ALTRA QUERY CHE USI LO SCOPE IDENTITY O ALTRO COSI DA PIGLIARSI LE ULTIME PK
        private static string AGGIUNGI_PARTITA = @"
            INSERT INTO dbo.Partite (Tipo,Campo,OraInizio,OraFine,Risultato)
            VALUES (@Tipo,@Campo,@DataIn,@DataF,@Ris) 
            SELECT SCOPE_IDENTITY()
         ";
        // INSERT INTO dbo.Prenotazioni (IdPartita,IdGiocatore) VALUES (@Tipo,@Campo,@DataIn,@DataF,@Ris);  //capire come inserire valori in più tabelle
        //Aggiungi un giocatore al database
        private static string ISCRIVI_GIOCATORI = @"
            INSERT INTO Giocatori(Nome,Cognome,DataNascita,Nickname,Livello) 
            values (@Nome,@Cognome,@DataNascita,@Nickname,@Livello)
         ";

        //Guardami se quel giorno a quell'ora il campo è libero
        private static string TROVA_PARTITA_DATA_ORA = @"
            SELECT *
            FROM dbo.Partite as P
            WHERE  P.OraInizio BETWEEN @Data AND @Data
         ";

        //Aggiungimi nella tabella di congiunzione id partita e giocatori
        public static string RIEMPI_TABELLA_UNIONE = @"
            INSERT INTO dbo.Prenotazioni (IdGiocatore,IdPartita) 
            values (@idGiocatore,@idPartita)
         ";

        //Calcolami il livello medio dei giocatori di età inferiore a..
        private static string TROVA_LIVELLO_MEDIO = @"
            SELECT AVG(Livello) as media
            FROM dbo.Giocatori
            where DATEDIFF(year, DataNascita, SYSDATETIME()) < @Anni
         ";

        //Dammi la lista di giocatori
        private static string LISTA_GIOCATORI = @"
            SELECT * FROM dbo.Giocatori ORDER BY Livello desc
         ";

        //Dammi la lista delle partite in programma
        private static string LISTA_PARTITE = @"
            SELECT * 
            FROM dbo.Partite 
            WHERE OraInizio > GETDATE()
         ";

        //  M E T O D I //
        // 1 //
        public void PartiteInData()
        {
            Console.WriteLine("Inserisci la data della partita:"); //messo tutto qui dentro, niente nel program
            DateTime data; // dopo la domanda di rito creo la variabile che prima era inserita come parametro
            //di questo metodo(look gian ex). E devo certificarla con il readline che piglia solo stringhe(!!!)
            data = DateTime.Parse(Console.ReadLine()); // dopo ciò tutto uguale lancio i comandi sql
            //DateTime maz = DateTime.Parse(valore);
            //Controllo.PartiteInData(data);
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING)) //ti connetti al database
            {
                conn.Open(); //apri la connessione
                using (SqlCommand cmd = new SqlCommand(STAMPA_PARTITE_IN_DATA, conn)) //attivi la query
                {
                    cmd.Parameters.AddWithValue("@Data", data);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine("\nID: " + reader["IdPartita"]);
                            Console.WriteLine("\nTipo: " + reader["Tipo"]);
                            Console.WriteLine("\nNumero Campo: " + reader["Campo"]);
                            Console.WriteLine("\nOra Inizio: " + reader["OraInizio"]);
                            Console.WriteLine("\nOra Fine: " + reader["OraFine"]);
                            Console.WriteLine("\nRisultato partita: " + reader["Risultato"]);
                        }
                    }
                }
            }
        }
        // 2 // non ritorno un oggetto partita(della classe) ma infilo i dati direttamente nel database
        public void IscrizionePartita()
        {
            try // ECCO COME PIAZZARE UNA ECCEZIONE
            {
                string tipo, oraInizio, oraFine, dataInizio, dataFine;
                int campo;
                int cont = 4;
                int[] giocatori = new int[4];
                Console.WriteLine("Tipo di partita: 1vs1/2vs2");
                tipo = Console.ReadLine();
                Console.WriteLine("\nChe campo Desiderate? (1-2-3-4)");
                campo = int.Parse(Console.ReadLine()); //Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("\n che giorno?");
                dataInizio = Console.ReadLine();
                Console.WriteLine("\nA che ora volete iniziare?");
                oraInizio = Console.ReadLine();
                Console.WriteLine("\nA che ora volete finire?");
                oraFine = Console.ReadLine();
                Console.WriteLine("Inserisci il risultato:");
                String risultato = Console.ReadLine();
                dataFine = dataInizio + " " + oraFine;
                dataInizio = dataInizio + " " + oraInizio;
                DateTime data1 = DateTime.Parse(dataInizio);
                DateTime data2 = DateTime.Parse(dataFine);
                if (tipo == "1vs1")
                {
                    cont = 2;
                    for (int i = 0; i < cont; i++)
                    {
                        Console.WriteLine("\nID giocatore" + i);
                        giocatori[i] = int.Parse(Console.ReadLine());
                        //int player = giocatori[i];
                    }
                }
                else
                {
                    for (int i = 0; i < cont; i++)
                    {
                        Console.WriteLine("\nID giocatore" + (i + 1));
                        giocatori[i] = int.Parse(Console.ReadLine());
                    }
                }
                int id = AddPartita(tipo, campo, data1, data2, risultato); // gli passi i parametri di sopra
                //string agg = aggiungi();
                Console.WriteLine("partita inserita con id:" + id);
                Iscrizione(id, giocatori, cont);
            }
            catch(FormatException ex)
            {
                Console.WriteLine("ECCEZIONE RILEVATA: " + ex);
                Console.WriteLine("\nINSERISCI LA DATA IN FORMATO GG-MM-AA E L'ORA IN FORMATO HH:MM\n");
                IscrizionePartita();
            }

        }
        // 3 //
        public int AddPartita(string tipo, int campo, DateTime dataInizio, DateTime dataFine, string risultato)
        {
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
            {
                conn.Open();
                
                using (SqlCommand cmd = new SqlCommand(AGGIUNGI_PARTITA, conn))
                {
                    
                    cmd.Parameters.AddWithValue("@Tipo", tipo);
                    cmd.Parameters.AddWithValue("@Campo", campo);
                    cmd.Parameters.AddWithValue("@DataIn", dataInizio);
                    cmd.Parameters.AddWithValue("@DataF", dataFine);
                    cmd.Parameters.AddWithValue("@Ris", risultato);
                    decimal result = /*(decimal)*/Convert.ToDecimal(cmd.ExecuteScalar()); // puoi fare sia il cast che usare il Covert.ToDecimal
                    return (int)result;
                }
            }
        }

        // 3 plus //
        public void Iscrizione(int id, int[] idGiocatore, int cont)
        {
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
            {
                conn.Open();
                for (int i = 0; i < cont; i++)
                {
                    using (SqlCommand cmd = new SqlCommand(RIEMPI_TABELLA_UNIONE, conn))
                    {
                        cmd.Parameters.AddWithValue("@idPartita", id);
                        cmd.Parameters.AddWithValue("@idGiocatore", idGiocatore[i]);
                        Console.WriteLine("Numero righe inserite: " + cmd.ExecuteNonQuery());
                    }
                }
            }
        }

        // 4 // qui facciamo ritornare un oggetto giocatore e lo buttiamo nel database
        public void IscrizioneGiocatore()
        {
            Console.WriteLine("Inserisci il nome: ");
            String nome = Console.ReadLine();
            Console.WriteLine("Inserisci il cognome: ");
            String cognome = Console.ReadLine();
            Console.WriteLine("Inserisci la data di nascita: ");
            String birthday = Console.ReadLine();
            DateTime dataNascita = DateTime.Parse(birthday);
            Console.WriteLine("Inserisci il nickname:");
            String nickname = Console.ReadLine();
            Console.WriteLine("Inserisci il livello del giocatore");
            int livello = Convert.ToInt32(Console.ReadLine());

            Giocatore giocatore = new Giocatore(nome, cognome, dataNascita, nickname, livello);
            //int idPartita=0;
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(ISCRIVI_GIOCATORI, conn))
                {
                    //cmd.Parameters.AddWithValue("@id",giocatore.idGiocatore);
                    cmd.Parameters.AddWithValue("@Nome", giocatore.nome);
                    cmd.Parameters.AddWithValue("@Cognome", giocatore.cognome);
                    cmd.Parameters.AddWithValue("@DataNascita", giocatore.dataNascita);
                    cmd.Parameters.AddWithValue("@Nickname", giocatore.nickname);
                    cmd.Parameters.AddWithValue("@Livello", giocatore.livello);
                    Console.WriteLine("Numero righe inserite: " + cmd.ExecuteNonQuery());
                }
            }
        }
        // 5 //
        public decimal ValoreMedG()
        {
            Console.WriteLine("Inserisci l'età massima");
            int eta;
            eta = Convert.ToInt32(Console.ReadLine());
            decimal media = 0;
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(TROVA_LIVELLO_MEDIO, conn))
                {
                    cmd.Parameters.AddWithValue("@Anni", eta);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            media = Convert.ToDecimal( reader["media"]); // Convert.ToInt32
                        }
                    }
                }
            }
            Console.WriteLine("\nLa media dei giocatori sotto i " + eta + " è: " + media);
            return media;
        }
        // 6 //
        public void ListaGiocatori()
        {
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING)) //ti connetti al database
            {
                conn.Open(); //apri la connessione
                using (SqlCommand cmd = new SqlCommand(LISTA_GIOCATORI, conn)) //attivi la query
                {
                    //cmd.Parameters.AddWithValue("@Data", data);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine(reader["Nome"].ToString()
                            + " " +
                            reader["Cognome"].ToString()
                            + " " + " ha attualmente un livello pari a " +
                            reader["Livello"].ToString());
                        }
                    }

                }

            }
        }
        // 7 //
        public void PartiteInProgramma()
        {
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING)) //ti connetti al database
            {
                conn.Open(); //apri la connessione
                using (SqlCommand cmd = new SqlCommand(LISTA_PARTITE, conn)) //attivi la query
                {
                    //cmd.Parameters.AddWithValue("@Data", data);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        Console.WriteLine("\nPartite in programma:\n");
                        while (reader.Read())
                        {
                            Console.WriteLine(reader["IdPartita"].ToString()
                            + " " +
                            reader["Tipo"].ToString()
                            + " " +
                            reader["Campo"].ToString()
                            + " " +
                            reader["OraInizio"].ToString());
                            //+ " " +
                            //reader["OraFine\n"].ToString());
                        }
                        Console.WriteLine("\nPress any key to continue");
                        Console.ReadLine();
                    }
                }
            }
        }
        // 8 //
        public void Elimina()
        {
            Console.WriteLine("Inserisci l' ID del giocatore: ");
            int id;
            id = Convert.ToInt32(Console.ReadLine());
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("BasketStation", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter property_id = cmd.Parameters.AddWithValue("@IdGiocatore", id);
                    cmd.ExecuteNonQuery();
                }
            }
            Console.WriteLine("\nIl giocatore con id " + id + " è stato eliminato");
        }
    }
}
