﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Basket2
{

    static class Stringa // in una classe statica avulsa dal resto, così la puoi richiamare quando e dove vuoi
    {
        public static string CONN_STRING = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Basket2;
                                            Integrated Security=True;Connect Timeout=30;
                        Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    }

    class TorreControllo
    {
        //Dammi la lista di giocatori
        private static string LISTA_GIOCATORI = @"
            SELECT * FROM dbo.Giocatori ORDER BY Livello desc
         ";

        private static string AGGIUNGI_PARTITA = @"
            INSERT INTO dbo.Partite (Tipo,Campo,OraInizio,OraFine,Risultato)
            VALUES (@Tipo,@Campo,@DataIn,@DataF,@Ris) 
            SELECT SCOPE_IDENTITY()
         ";
        //Aggiungimi nella tabella di congiunzione id partita e giocatori
        public static string RIEMPI_TABELLA_UNIONE = @"
            INSERT INTO dbo.Prenotazioni (IdGiocatore,IdPartita) 
            values (@idGiocatore,@idPartita)
         ";

        // 2 // non ritorno un oggetto partita(della classe) ma infilo i dati direttamente nel database
        public void IscrizionePartita()
        {
            try // ECCO COME PIAZZARE UNA ECCEZIONE
            {
                int id;
                int cont = 4;
                int[] giocatori = new int[4];
                Console.WriteLine("Tipo di partita: 1vs1/2vs2");
                string tipo = Console.ReadLine();
                Console.WriteLine("\nChe campo Desiderate? (1-2-3-4)");
                int campo = int.Parse(Console.ReadLine()); //Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("\ngiorno e ora inzio [dd-mm-yyyy hh:mm");
                DateTime dataInizio = DateTime.Parse( Console.ReadLine());
                Console.WriteLine("\ngiorno e ora fine [dd-mm-yyyy hh:mm");
                DateTime dataFine = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Inserisci il risultato:");
                String risultato = Console.ReadLine();
                if (tipo == "1vs1")
                {
                    cont = 2;
                    for (int i = 0; i < cont; i++)
                    {
                        Console.WriteLine("\nID giocatore" + i);
                        giocatori[i] = int.Parse(Console.ReadLine());
                        //int player = giocatori[i];
                    }
                }
                else
                {
                    for (int i = 0; i < cont; i++)
                    {
                        Console.WriteLine("\nID giocatore" + (i + 1));
                        giocatori[i] = int.Parse(Console.ReadLine());
                    }
                }
                Partita partita = new Partita(tipo, campo, dataInizio, dataFine, risultato);
                using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(AGGIUNGI_PARTITA, conn))
                    {
                        //cmd.Parameters.AddWithValue("@id",giocatore.idGiocatore);
                        cmd.Parameters.AddWithValue("@Tipo", partita.tipo);
                        cmd.Parameters.AddWithValue("@Campo", partita.campo);
                        cmd.Parameters.AddWithValue("@DataIn", partita.oraInizio);
                        cmd.Parameters.AddWithValue("@DataF", partita.oraFine);
                        cmd.Parameters.AddWithValue("@Ris", partita.risultato);
                        id = Convert.ToInt32(cmd.ExecuteScalar());
                        Console.WriteLine("Partita inserita con id: " + id);
                    }
                    for (int i = 0; i < cont; i++)
                    {
                        using (SqlCommand cmd = new SqlCommand(RIEMPI_TABELLA_UNIONE, conn))
                        {
                            cmd.Parameters.AddWithValue("@idPartita", id);
                            cmd.Parameters.AddWithValue("@idGiocatore", giocatori[i]);
                            Console.WriteLine("Numero righe inserite: " + cmd.ExecuteNonQuery());
                        }
                    }
                }
                //using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING))
                //{
                //    conn.Open();
                    
                //}
                //Console.WriteLine("partita inserita con id:" + id);
                //Iscrizione(id, giocatori, cont);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("ECCEZIONE RILEVATA: " + ex);
                Console.WriteLine("\nINSERISCI LA DATA IN FORMATO GG-MM-AA E L'ORA IN FORMATO HH:MM\n");
                //IscrizionePartita();
            }

        }


        public void ListaGiocatori()
        {
            using (SqlConnection conn = new SqlConnection(Stringa.CONN_STRING)) //ti connetti al database
            {
                conn.Open(); //apri la connessione
                using (SqlCommand cmd = new SqlCommand(LISTA_GIOCATORI, conn)) //attivi la query
                {
                    //cmd.Parameters.AddWithValue("@Data", data);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Console.WriteLine(reader["Nome"].ToString()
                            + " " +
                            reader["Cognome"].ToString()
                            + " " + " ha attualmente un livello pari a " +
                            reader["Livello"].ToString());
                        }
                    }

                }

            }
        }
    }
}
