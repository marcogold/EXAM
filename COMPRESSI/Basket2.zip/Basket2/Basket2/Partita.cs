﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Basket2
{
    class Partita
    {
        public int idPartita { get; }
        public string tipo { get; set; }
        public int campo { get; set; }
        public DateTime oraInizio { get; set; }
        public DateTime oraFine { get; set; }
        public string risultato { get; set; }

        public Partita(string tipo, int campo, DateTime inizio, DateTime fine, string risultato)
        {
            this.tipo = tipo;
            this.campo = campo;
            this.oraInizio = inizio;
            this.oraFine = fine;
            this.risultato = risultato;
        }
    }
}
