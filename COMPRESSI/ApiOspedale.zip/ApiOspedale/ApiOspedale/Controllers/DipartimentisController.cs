﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiOspedale.Model;
using Microsoft.AspNetCore.Cors;

namespace ApiOspedale.Controllers
{
    [EnableCors("MyPolicyCORS")]
    [Route("api/dipartimenti")]
    [ApiController]
    public class DipartimentisController : ControllerBase
    {
        private Repository repo;

        public DipartimentisController(Repository r)
        {
            this.repo = r;
        }
        
        // localhost/api/dipartimenti
        [HttpGet]
        public IEnumerable<Dipartimenti> GetDipartimenti()
        {
            return repo.GetAllDipartimenti();
        }











        //        // GET: api/Dipartimentis/5
        //        [HttpGet("{id}")]
        //        public async Task<IActionResult> GetDipartimenti([FromRoute] int id)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            var dipartimenti = await _context.Dipartimenti.FindAsync(id);

        //            if (dipartimenti == null)
        //            {
        //                return NotFound();
        //            }

        //            return Ok(dipartimenti);
        //        }

        //        // PUT: api/Dipartimentis/5
        //        [HttpPut("{id}")]
        //        public async Task<IActionResult> PutDipartimenti([FromRoute] int id, [FromBody] Dipartimenti dipartimenti)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            if (id != dipartimenti.IdDipartimento)
        //            {
        //                return BadRequest();
        //            }

        //            _context.Entry(dipartimenti).State = EntityState.Modified;

        //            try
        //            {
        //                await _context.SaveChangesAsync();
        //            }
        //            catch (DbUpdateConcurrencyException)
        //            {
        //                if (!DipartimentiExists(id))
        //                {
        //                    return NotFound();
        //                }
        //                else
        //                {
        //                    throw;
        //                }
        //            }

        //            return NoContent();
        //        }

        //        // POST: api/Dipartimentis
        //        [HttpPost]
        //        public async Task<IActionResult> PostDipartimenti([FromBody] Dipartimenti dipartimenti)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            _context.Dipartimenti.Add(dipartimenti);
        //            await _context.SaveChangesAsync();

        //            return CreatedAtAction("GetDipartimenti", new { id = dipartimenti.IdDipartimento }, dipartimenti);
        //        }

        //        // DELETE: api/Dipartimentis/5
        //        [HttpDelete("{id}")]
        //        public async Task<IActionResult> DeleteDipartimenti([FromRoute] int id)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            var dipartimenti = await _context.Dipartimenti.FindAsync(id);
        //            if (dipartimenti == null)
        //            {
        //                return NotFound();
        //            }

        //            _context.Dipartimenti.Remove(dipartimenti);
        //            await _context.SaveChangesAsync();

        //            return Ok(dipartimenti);
        //        }

        //        private bool DipartimentiExists(int id)
        //        {
        //            return _context.Dipartimenti.Any(e => e.IdDipartimento == id);
        //        }
    }
}