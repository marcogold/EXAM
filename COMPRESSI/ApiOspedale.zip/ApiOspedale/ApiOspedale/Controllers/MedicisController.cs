﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiOspedale.Model;
using Microsoft.AspNetCore.Cors;
using ApiOspedale.DTO;

namespace ApiOspedale.Controllers
{
    [EnableCors("MyPolicyCORS")]
    [Route("api/medici")]
    [ApiController]
    public class MedicisController : Controller
    {
        private Repository repo;

        public MedicisController(Repository r)
        {
            this.repo = r;
        }

        //localhost/api/medici
        [HttpGet("{cazzo}")]
        public List<Medici> GetMedici()
        {
            return repo.GetAllMedici().ToList();
        }

        [HttpGet]
        public List<MediciVModel> GetMedici (int numero, int dipartimento)
        {
            if(numero == 0)
            {
                //se n = 0 allora te ne crea uno nuovo
                return repo.GetMediciPlus().Select(m => new MediciVModel(m)).ToList()/*.Select(m => m.ToDTO())*/;
            }
            else
            {
                //li seleziona e la menata del select è solo per far comparire il nome del dipartimento di fianco al medico
                return repo.MediciPiuAnziani(numero, dipartimento).Select(m => new MediciVModel(m)).ToList();
            }
        }















        //        // GET: api/Medicis/5
        //        [HttpGet("{id}")]
        //        public async Task<IActionResult> GetMedici([FromRoute] int id)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            var medici = await _context.Medici.FindAsync(id);

        //            if (medici == null)
        //            {
        //                return NotFound();
        //            }

        //            return Ok(medici);
        //        }

        //        // PUT: api/Medicis/5
        //        [HttpPut("{id}")]
        //        public async Task<IActionResult> PutMedici([FromRoute] int id, [FromBody] Medici medici)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            if (id != medici.IdMedico)
        //            {
        //                return BadRequest();
        //            }

        //            _context.Entry(medici).State = EntityState.Modified;

        //            try
        //            {
        //                await _context.SaveChangesAsync();
        //            }
        //            catch (DbUpdateConcurrencyException)
        //            {
        //                if (!MediciExists(id))
        //                {
        //                    return NotFound();
        //                }
        //                else
        //                {
        //                    throw;
        //                }
        //            }

        //            return NoContent();
        //        }

        //        // POST: api/Medicis
        //        [HttpPost]
        //        public async Task<IActionResult> PostMedici([FromBody] Medici medici)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            _context.Medici.Add(medici);
        //            await _context.SaveChangesAsync();

        //            return CreatedAtAction("GetMedici", new { id = medici.IdMedico }, medici);
        //        }

        //        // DELETE: api/Medicis/5
        //        [HttpDelete("{id}")]
        //        public async Task<IActionResult> DeleteMedici([FromRoute] int id)
        //        {
        //            if (!ModelState.IsValid)
        //            {
        //                return BadRequest(ModelState);
        //            }

        //            var medici = await _context.Medici.FindAsync(id);
        //            if (medici == null)
        //            {
        //                return NotFound();
        //            }

        //            _context.Medici.Remove(medici);
        //            await _context.SaveChangesAsync();

        //            return Ok(medici);
        //        }

        //        private bool MediciExists(int id)
        //        {
        //            return _context.Medici.Any(e => e.IdMedico == id);
        //        }
    }
}