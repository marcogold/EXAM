﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiOspedale.Model
{
    public class Repository
    {
        private HospitalContext ctx;

        public Repository(HospitalContext context)
        {
            this.ctx = context;
        }
        
        //ritorna la lista di tutti i dipartimenti
        public List<Dipartimenti> GetAllDipartimenti()
        {
            return ctx.Dipartimenti.ToList();
        }

        //ritorna la lista di tutti i medici
        public List<Medici> GetAllMedici()
        {
            return ctx.Medici.ToList();
        }

        //ritorna la lista di medici + si porta dietro tutte le proprietà della classe Dipartimento grazie a "Dept"
        public List<Medici> GetMediciPlus()
        {
            return ctx.Medici.Include(d => d.Dept).ToList();
        }

        //ritorna una lista di medici in base al numero dato e all'ID del dipartimento.
        //QUERY: deptId = all'id del dipartimento che si inserice,medici ordinati per datadiassunzione, prende gli n dati utili indicati, 
        // e include nel risultato l'oggetto Dipartimento Dept, che si porta dietro tutte le proprietà utili.
        public List<Medici> MediciPiuAnziani (int n, int dipartimento)
        {
            return ctx.Medici.Where(d => d.DeptId == dipartimento).OrderByDescending(x => x.DataAssunzione).Take(n).Include(x => x.Dept).ToList();
        }
    }
}
