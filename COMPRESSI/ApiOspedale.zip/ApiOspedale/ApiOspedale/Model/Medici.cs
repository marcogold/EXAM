﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiOspedale.Model
{
    public partial class Medici
    {
        public Medici()
        {
            Dipartimenti = new HashSet<Dipartimenti>();
        }

        [Key]
        public int IdMedico { get; set; }
        [Required]
        [StringLength(50)]
        public string Nome { get; set; }
        [Required]
        [StringLength(50)]
        public string Cognome { get; set; }
        [Column(TypeName = "date")]
        public DateTime DataNascita { get; set; }
        [Column(TypeName = "date")]
        public DateTime DataAssunzione { get; set; }
        public int? DeptId { get; set; }

        [ForeignKey("DeptId")]
        [InverseProperty("Medici")]
        public Dipartimenti Dept { get; set; }
        [InverseProperty("Primario")]
        public ICollection<Dipartimenti> Dipartimenti { get; set; }
    }
}
