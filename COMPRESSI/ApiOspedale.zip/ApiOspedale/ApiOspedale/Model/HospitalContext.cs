﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ApiOspedale.Model
{
    public partial class HospitalContext : DbContext
    {
        public HospitalContext()
        {
        }

        public HospitalContext(DbContextOptions<HospitalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Dipartimenti> Dipartimenti { get; set; }
        public virtual DbSet<Medici> Medici { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Hospital;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Dipartimenti>(entity =>
            {
                entity.HasOne(d => d.Primario)
                    .WithMany(p => p.Dipartimenti)
                    .HasForeignKey(d => d.PrimarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Dipartimenti_Medici");
            });

            modelBuilder.Entity<Medici>(entity =>
            {
                entity.HasOne(d => d.Dept)
                    .WithMany(p => p.Medici)
                    .HasForeignKey(d => d.DeptId)
                    .HasConstraintName("FK_Medici_Dipartimenti");
            });
        }
    }
}
