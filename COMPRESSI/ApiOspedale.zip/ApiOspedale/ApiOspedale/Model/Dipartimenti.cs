﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiOspedale.Model
{
    public partial class Dipartimenti
    {
        public Dipartimenti()
        {
            Medici = new HashSet<Medici>();
        }

        [Key]
        public int IdDipartimento { get; set; }
        [Required]
        [StringLength(50)]
        public string Nome { get; set; }
        [Required]
        [StringLength(50)]
        public string Area { get; set; }
        public int PrimarioId { get; set; }

        [ForeignKey("PrimarioId")]
        [InverseProperty("Dipartimenti")]
        public Medici Primario { get; set; }
        [InverseProperty("Dept")]
        public ICollection<Medici> Medici { get; set; }
    }
}
