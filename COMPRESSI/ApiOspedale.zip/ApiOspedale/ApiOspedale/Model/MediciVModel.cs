﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiOspedale.Model
{
    public class MediciVModel
    {
        public int IdMedico { get; set; }
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public DateTime DataNascita { get; set; }
        public DateTime DataAssunzione { get; set; }
        public string Dipartimento { get; set; }

        //tutta sta merda per questo, assegnare al deptid del medico il nome del dipartimento
        //così da poterlo usare per risolvere il primo punto dell'esame
        public MediciVModel(Medici medico)
        {
            IdMedico = medico.IdMedico;
            Nome = medico.Nome;
            Cognome = medico.Cognome;
            DataNascita = medico.DataNascita;
            DataAssunzione = medico.DataAssunzione;
            Dipartimento = medico.Dept.Nome;
        }

        public MediciVModel()
        {

        }
    }
}
