﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiOspedale.DTO
{
    public class MediciDTO
    {
        public int IdMedico { get; set; }
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public DateTime DataNascita { get; set; }
        public DateTime DataAssunzione { get; set; }
        public string Dipartimento { get; set; }
    }
}
