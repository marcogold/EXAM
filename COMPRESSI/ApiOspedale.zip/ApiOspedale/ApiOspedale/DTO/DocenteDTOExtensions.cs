﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiOspedale.Model;

namespace ApiOspedale.DTO
{
    public static class DocenteDTOExtensions
    {
        public static MediciDTO ToDTO(this MediciVModel med)
        {
            return new MediciDTO
            {
                IdMedico = med.IdMedico,
                Nome = med.Nome,
                Cognome = med.Cognome,
                DataNascita = med.DataNascita,
                DataAssunzione = med.DataAssunzione,
                Dipartimento = med.Dipartimento
            };
        }
    }
}
