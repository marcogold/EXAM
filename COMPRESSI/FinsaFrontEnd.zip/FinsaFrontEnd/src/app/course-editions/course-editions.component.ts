import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-editions',
  templateUrl: './course-editions.component.html',
  styleUrls: ['./course-editions.component.css']
})
export class CourseEditionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
