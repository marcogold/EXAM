export interface CourseEdition{
    idEdizioneCorso :number,
    idCorso :number,
    dataInizio :Date
}