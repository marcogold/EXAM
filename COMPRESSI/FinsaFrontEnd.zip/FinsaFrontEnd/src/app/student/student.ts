export interface Student{
    idStudente: number;
    nome: string;
    cognome: string;
    codiceFiscale: string;
    tipoStudente: string;
}