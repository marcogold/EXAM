export interface Course{
    idCorso: number,
    titolo: string,
    prezzoBase: number,
    difficolta: number
}