export interface Instructor{
    idDocente: number;
    nome:string;
    cognome: string;
    dataNascita: Date;
    eta: number;
    tipoDocente:string;
    cf:string;
}