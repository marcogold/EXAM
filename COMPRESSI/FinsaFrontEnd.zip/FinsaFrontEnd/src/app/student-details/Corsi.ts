export interface Corso{
    idCorso: string;
    titolo: string;
    prezzoBase: string;
    difficolta: string;
}
