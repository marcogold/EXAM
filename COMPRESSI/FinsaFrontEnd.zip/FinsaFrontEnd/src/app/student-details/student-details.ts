export interface Student{
    nome: string;
    cognome: string;
    codiceFiscale: string;
    tipoStudente: string;
}