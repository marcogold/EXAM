export class StudentForm{
    constructor(
    public nome = '',
    public cognome= '',
    public codiceFiscale = '',
    public tipoStudente= ''){ }

}