import { Component } from "@angular/core";

@Component({
    template: `
    <h1>BENVENUTO / WELCOME / WILLKOMMEN</h1>
    <h3>QUI SI GESTISCE TUTTO CIO' CHE RIGUARDA IL NOSTRO ISTITUTO, A PARTIRE DAI CORSI FINO AD ARRIVARE AI DOCENTI E AGLI ALLIEVI!</h3>
    <br>
    <br>
    <h4>
    <a>Collegati al nostro progetto! Clicca sull'immagine!</a>
    </h4>
    <a href="https://github.com/daniele1973">
    <img src="https://camo.githubusercontent.com/7710b43d0476b6f6d4b4b2865e35c108f69991f3/68747470733a2f2f7777772e69636f6e66696e6465722e636f6d2f646174612f69636f6e732f6f637469636f6e732f313032342f6d61726b2d6769746875622d3235362e706e67">
    </a>
    `
})
export class WelcomeComponent {

}