export class InstructorForm{
    constructor(
    public nome = '',
    public cognome= '',
    public cF = '',
    public tipoDocente= '',
    public dataNascita= new Date()){ }

}