export interface CourseInstructor {
    idEdizioneCorso?: number;
    idDocente?: number;
  }