export interface ECourse {
    idEdizioneCorso: number;
    idCorso: number;
    dataInizio: Date;
}
