export interface CourseStudent {
  iDEdizioneCorso?: number;
  iDAllievo?: number;
}
