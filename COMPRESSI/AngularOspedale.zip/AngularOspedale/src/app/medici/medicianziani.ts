import { Component, OnInit } from '@angular/core';
import { Dipartimento } from './dipartimento';
import { Medico } from './medico';
import { MediciService } from './medici.service';

@Component({
  templateUrl: './medicianziani.html',
  styleUrls: ['./medicianziani.css']
})
export class MediciAnziani  implements OnInit {

    private medici:Medico[];
    private dipartimenti:Dipartimento[];
    private _numero:number;
    private _dipartimento:number;
    errorMessage:string;
  
    constructor(private  service:MediciService) {
        this.numero=2;
        this.dipartimento=null;
    }
  
    set numero(x:number)
    {
        if(x>0)
        {
            this._numero=x;
            this.onChange(); //richiama qui onchange
        }
    }
  
    get numero()
    {
        return this._numero;
    }
  
    set dipartimento(x:number)
    {
      this._dipartimento=x;
      this.onChange();//richiama qui onchange
    }
  
    get dipartimento()
    {
        return this._dipartimento;
    }
  
    ngOnInit(): void {
      this.service.getDipartimenti().subscribe(
          dipartimenti => {
            this.dipartimenti = dipartimenti;
          },
          error => this.errorMessage = <any>error
        );
    }
  
    onChange()
    {
      this.service.getImpiegatiAnziani(this.numero,this.dipartimento).subscribe(
          medici => {
            this.medici = medici;
          },
          error => this.errorMessage = <any>error
        );
    }
}