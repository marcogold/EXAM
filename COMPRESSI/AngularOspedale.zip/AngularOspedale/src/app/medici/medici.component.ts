import { Component, OnInit } from '@angular/core';
import { Medico } from './medico';
import { MediciService } from './medici.service';

@Component({
  selector: 'app-medici',
  templateUrl: './medici.component.html',
  styleUrls: ['./medici.component.css']
})
export class MediciComponent implements OnInit {

  private medici:Medico[];
  errormessage:string;

  constructor(private service:MediciService) { }

  ngOnInit() {
    this.service.getMedici().subscribe(
      medici => {
        this.medici = medici;
      },
      error => this.errormessage = <any>error
    );
  }

}
