export class Medico{
    idMedico:number;
    nome:string;
    cognome:string;
    dataNascita:Date;
    dataAssunzione:Date;
    dipartimento:string;
}