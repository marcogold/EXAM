import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Medico } from './medico';
import { Dipartimento } from './dipartimento';



@Injectable({
  providedIn: 'root',
})
export class MediciService {

  private mediciUrl="https://localhost:44365/api/medici";
  private dipartimentiURL="https://localhost:44365/api/dipartimenti"
  constructor(private http: HttpClient) { }

  getMedici(): Observable<Medico[]> {
    return this.http.get<Medico[]>(this.mediciUrl)
      .pipe(
        tap(data => console.log(JSON.stringify(data)))
      );
  }

  getDipartimenti():Observable<Dipartimento[]>
  {
    return this.http.get<Dipartimento[]>(this.dipartimentiURL)
    .pipe(
      tap(data => console.log(JSON.stringify(data)))
    );
  }

  getImpiegatiAnziani(num:number,dipartimento:number):Observable<Medico[]>
  {
    return this.http.get<Medico[]>(this.mediciUrl+"?numero="+num+"&dipartimento="+dipartimento)
    .pipe(
      tap(data => console.log(JSON.stringify(data)))
    );
  }
}