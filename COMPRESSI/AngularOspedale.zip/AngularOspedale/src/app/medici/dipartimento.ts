export class Dipartimento{
     idDipartimento:number;
     nome:string;
     area:string;
     primarioId:number;   
}