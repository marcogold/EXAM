﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcPersonello.Model
{
    public partial class Registrazioni
    {
        public int Autore { get; set; }
        public int Presentazione { get; set; }

        [ForeignKey("Autore")]
        [InverseProperty("Registrazioni")]
        public Autori AutoreNavigation { get; set; }
        [ForeignKey("Presentazione")]
        [InverseProperty("Registrazioni")]
        public Presentazioni PresentazioneNavigation { get; set; }
    }
}
