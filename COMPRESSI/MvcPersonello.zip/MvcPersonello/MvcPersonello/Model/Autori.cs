﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcPersonello.Model
{
    public partial class Autori
    {
        public Autori()
        {
            Registrazioni = new HashSet<Registrazioni>();
        }

        public int Id { get; set; }
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Skill { get; set; }
        [RegularExpression(@"^((\+91-?)|0)?[0-9]{10}$", ErrorMessage = "Entered phone format is not valid.")]
        public string Telefono { get; set; }

        [InverseProperty("AutoreNavigation")]
        public ICollection<Registrazioni> Registrazioni { get; set; }
    }
}
