﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcPersonello.Model
{
    public partial class Presentazioni
    {
        public Presentazioni()
        {
            Registrazioni = new HashSet<Registrazioni>();
        }

        public int Id { get; set; }
        public DateTime Fine { get; set; }
        public DateTime Inizio { get; set; }
        [Required]
        public string Livello { get; set; }
        [Required]
        public string Titolo { get; set; }

        [InverseProperty("PresentazioneNavigation")]
        public ICollection<Registrazioni> Registrazioni { get; set; }
    }
}
