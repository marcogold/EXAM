﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcPersonello.Model.ViewModel
{
    public class PresentazioneViewModel
    {
        public int Id { get; set; }
        public DateTime Fine { get; set; }
        public DateTime Inizio { get; set; }
        public string Livello { get; set; }
        public string Titolo { get; set; }
        public int IdAutore { get; set; }

        public List<Autori> autori = new List<Autori>();
    }
}
