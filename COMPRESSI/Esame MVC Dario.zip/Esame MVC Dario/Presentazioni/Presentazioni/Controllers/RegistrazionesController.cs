﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Presentazioni.Models.Database;

namespace Presentazioni.Controllers
{
    public class RegistrazionesController : Controller
    {
        private readonly Contesto _context;

        public RegistrazionesController(Contesto context)
        {
            _context = context;
        }

        // GET: Registraziones
        public async Task<IActionResult> Index()
        {
            var contesto = _context.Registrazioni.Include(r => r.AutoreNavigation).Include(r => r.PresentazioneNavigation);
            return View(await contesto.ToListAsync());
        }

        // GET: Registraziones/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var registrazione = await _context.Registrazioni
                .Include(r => r.AutoreNavigation)
                .Include(r => r.PresentazioneNavigation)
                .SingleOrDefaultAsync(m => m.Autore == id);
            if (registrazione == null)
            {
                return NotFound();
            }

            return View(registrazione);
        }

        // GET: Registraziones/Create
        public IActionResult Create()
        {
            ViewData["Autore"] = new SelectList(_context.Autori, "Id", "Email");
            ViewData["Presentazione"] = new SelectList(_context.Presentazioni, "Id", "Livello");
            return View();
        }

        // POST: Registraziones/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Autore,Presentazione")] Registrazione registrazione)
        {
            if (ModelState.IsValid)
            {
                _context.Add(registrazione);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["Autore"] = new SelectList(_context.Autori, "Id", "Email", registrazione.Autore);
            ViewData["Presentazione"] = new SelectList(_context.Presentazioni, "Id", "Livello", registrazione.Presentazione);
            return View(registrazione);
        }

        // GET: Registraziones/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var registrazione = await _context.Registrazioni.SingleOrDefaultAsync(m => m.Autore == id);
            if (registrazione == null)
            {
                return NotFound();
            }
            ViewData["Autore"] = new SelectList(_context.Autori, "Id", "Email", registrazione.Autore);
            ViewData["Presentazione"] = new SelectList(_context.Presentazioni, "Id", "Livello", registrazione.Presentazione);
            return View(registrazione);
        }

        // POST: Registraziones/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Autore,Presentazione")] Registrazione registrazione)
        {
            if (id != registrazione.Autore)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(registrazione);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RegistrazioneExists(registrazione.Autore))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Autore"] = new SelectList(_context.Autori, "Id", "Email", registrazione.Autore);
            ViewData["Presentazione"] = new SelectList(_context.Presentazioni, "Id", "Livello", registrazione.Presentazione);
            return View(registrazione);
        }

        // GET: Registraziones/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var registrazione = await _context.Registrazioni
                .Include(r => r.AutoreNavigation)
                .Include(r => r.PresentazioneNavigation)
                .SingleOrDefaultAsync(m => m.Autore == id);
            if (registrazione == null)
            {
                return NotFound();
            }

            return View(registrazione);
        }

        // POST: Registraziones/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var registrazione = await _context.Registrazioni.SingleOrDefaultAsync(m => m.Autore == id);
            _context.Registrazioni.Remove(registrazione);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RegistrazioneExists(int id)
        {
            return _context.Registrazioni.Any(e => e.Autore == id);
        }
    }
}
